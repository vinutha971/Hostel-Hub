@echo off
echo Building Smart Hostel Management System...
gcc -Wall -Wextra -std=c11 -O2 main.c hostel.c -o smart_hostel.exe
if errorlevel 1 (echo Build failed.& pause & exit /b 1)
echo Build successful.
pause
