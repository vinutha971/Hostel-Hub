// Reserved for a future browser dashboard. Current functionality is implemented in C.
