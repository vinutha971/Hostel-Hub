#include "hostel.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <direct.h>
#define MKDIR(p) _mkdir(p)
#else
#include <sys/stat.h>
#define MKDIR(p) mkdir(p,0755)
#endif

#define DATA_FILE "data/students.dat"
static void read_line(const char *prompt,char *buf,size_t n) {
    printf("%s",prompt); if(fgets(buf,(int)n,stdin)) { buf[strcspn(buf,"\r\n")]=0; }
}
static int read_int(const char *prompt) { char b[40]; read_line(prompt,b,sizeof b); return atoi(b); }
int main(void) {
    Student *head=NULL; int choice, id, paid; char name[NAME_LEN],room[ROOM_LEN],phone[PHONE_LEN];
    MKDIR("data"); load_students(&head,DATA_FILE);
    puts("========================================");
    puts("       SMART HOSTEL MANAGEMENT SYSTEM");
    puts("========================================");
    do {
        puts("\n1. Add student\n2. View all students\n3. Search student\n4. Update room / fee\n5. Delete student\n6. Dashboard summary\n0. Save and exit");
        choice=read_int("Enter choice: ");
        switch(choice) {
        case 1:
            id=read_int("Student ID: ");
            if(id<=0 || find_student(head,id)) { puts("Invalid or duplicate ID."); break; }
            read_line("Student name: ",name,sizeof name);
            read_line("Room number: ",room,sizeof room);
            read_line("Phone number: ",phone,sizeof phone);
            if(!name[0] || !room[0] || !phone[0]) { puts("Fields cannot be empty."); break; }
            paid=read_int("Fee paid? (1=yes, 0=no): ") ? 1:0;
            { Student *s=create_student(id,name,room,phone,paid); if(!s) puts("Memory allocation failed."); else { add_student(&head,s); save_students(head,DATA_FILE); puts("Student added successfully."); } }
            break;
        case 2: display_students(head); break;
        case 3:
            id=read_int("Enter student ID: ");
            { Student *s=find_student(head,id); if(s) { Student *one=s; display_students(one); } else puts("Student not found."); }
            break;
        case 4:
            id=read_int("Student ID: "); read_line("New room number: ",room,sizeof room);
            paid=read_int("Fee paid? (1=yes, 0=no): ") ? 1:0;
            if(update_student(head,id,room,paid)) { save_students(head,DATA_FILE); puts("Record updated."); } else puts("Student not found.");
            break;
        case 5:
            id=read_int("Student ID to delete: ");
            if(remove_student(&head,id)) { save_students(head,DATA_FILE); puts("Student deleted."); } else puts("Student not found.");
            break;
        case 6: {
            int total=count_students(head), pending=0, paid_count=0;
            for(Student *p=head;p;p=p->next) p->fee_paid?paid_count++:pending++;
            printf("\nHOSTEL DASHBOARD\nTotal residents : %d\nFees paid       : %d\nFees pending    : %d\n",total,paid_count,pending);
            break;
        }
        case 0: save_students(head,DATA_FILE); puts("Data saved. Goodbye."); break;
        default: puts("Choose a valid menu option.");
        }
    } while(choice!=0);
    free_students(&head); return 0;
}
