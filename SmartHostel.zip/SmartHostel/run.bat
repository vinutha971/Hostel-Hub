@echo off
if not exist smart_hostel.exe call build.bat
if exist smart_hostel.exe smart_hostel.exe
