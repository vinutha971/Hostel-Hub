# Smart Hostel Management System

A menu-driven hostel resident management application written in **C**. It uses a **singly linked list** to store student records and file handling to save records permanently in `data/students.dat`.

## Features
- Add, view, search, update and delete student records
- Allocate/change room numbers
- Track hostel fee status (paid or pending)
- Dashboard with resident and fee summaries
- Duplicate student-ID validation
- Persistent storage using file handling
- Dynamic memory allocation and linked-list operations

## 1. Run on Windows (VS Code)
1. Install GCC (MSYS2 MinGW-w64 or MinGW).
2. Open the `SmartHostel` folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:
   ```
   build.bat
   smart_hostel.exe
   ```
   Or double-click `run.bat`.

## 2. Run on Linux / macOS
```
make
./smart_hostel
```
Stop by choosing `0`. Records are saved automatically after changes.

## 3. Project structure
```
SmartHostel/
├── main.c              Menu, input and application workflow
├── hostel.c            Linked-list operations and file handling
├── hostel.h            Student structure and declarations
├── build.bat           Windows build script
├── run.bat             Build/run helper
├── Makefile            GCC build configuration
├── data/students.dat   Persistent sample student records
├── public/             Optional UI planning assets
└── docs/               Project documentation
```

## 4. Where concepts are implemented (viva)
| Concept | File / function | Explanation |
|---|---|---|
| Structure | `hostel.h` → `Student` | Stores ID, name, room, phone, fee status and next pointer |
| Dynamic allocation | `hostel.c` → `create_student()` | Allocates each node using `malloc()` |
| Insertion | `add_student()` | Adds a new node at the end of the list |
| Traversal | `display_students()`, `count_students()` | Visits each node using `next` |
| Searching | `find_student()` | Finds a record using student ID |
| Updating | `update_student()` | Changes room and fee status |
| Deletion | `remove_student()` | Unlinks the matching node and calls `free()` |
| File read | `load_students()` | Loads saved records using `fopen()` and `fgets()` |
| File write | `save_students()` | Stores each record in a text file |
| Memory cleanup | `free_students()` | Releases all allocated nodes |

## 5. Data file format
Each line uses:
```
id|name|room|phone|fee_paid
1001|Aarav Sharma|A-101|9876543210|1
```
`fee_paid` is `1` for paid and `0` for pending. Keep the `|` separator out of entered values.

## 6. Test checklist
- [ ] Add a student with a unique ID
- [ ] Try adding the same ID again (must be rejected)
- [ ] View all student records
- [ ] Search using an existing and a missing ID
- [ ] Update a student's room and fee status
- [ ] Delete a student and confirm it disappears
- [ ] Check dashboard totals
- [ ] Exit and restart; confirm records remain saved

## 7. Screenshots for submission
1. VS Code project folder / file tree
2. Build success in terminal
3. Main menu running
4. Add student operation
5. View all students
6. Search or update operation
7. Dashboard summary
8. `data/students.dat` opened in VS Code

## 8. Troubleshooting
| Problem | Fix |
|---|---|
| `gcc is not recognized` | Install GCC and add its `bin` folder to Windows PATH; reopen VS Code |
| `undefined reference to WinMain@16` | Compile `main.c` and `hostel.c` together using the supplied build command |
| `No such file or directory` for data file | Run the program from the `SmartHostel` project folder; the app creates `data/` if needed |
| Records do not appear | Check `data/students.dat` and make sure you launched the executable from the project folder |

## Scope note
This is a working C console prototype for core hostel resident and fee management. Room capacity validation, attendance, complaints, visitor logs, warden login and a connected web dashboard are possible future enhancements.
