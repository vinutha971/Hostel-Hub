#ifndef HOSTEL_H
#define HOSTEL_H
#define NAME_LEN 80
#define ROOM_LEN 20
#define PHONE_LEN 20
typedef struct Student {
    int id;
    char name[NAME_LEN], room[ROOM_LEN], phone[PHONE_LEN];
    int fee_paid;
    struct Student *next;
} Student;
Student *create_student(int id, const char *name, const char *room, const char *phone, int fee_paid);
void add_student(Student **head, Student *node);
Student *find_student(Student *head, int id);
int remove_student(Student **head, int id);
int update_student(Student *head, int id, const char *room, int fee_paid);
int count_students(const Student *head);
int save_students(const Student *head, const char *path);
int load_students(Student **head, const char *path);
void display_students(const Student *head);
void free_students(Student **head);
#endif
