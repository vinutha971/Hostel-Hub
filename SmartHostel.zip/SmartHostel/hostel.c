#include "hostel.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

Student *create_student(int id, const char *name, const char *room, const char *phone, int fee_paid) {
    Student *s = (Student *)malloc(sizeof(Student));
    if (!s) return NULL;
    s->id=id; snprintf(s->name,NAME_LEN,"%s",name); snprintf(s->room,ROOM_LEN,"%s",room);
    snprintf(s->phone,PHONE_LEN,"%s",phone); s->fee_paid=fee_paid; s->next=NULL; return s;
}
void add_student(Student **head, Student *node) {
    if (!head || !node) return;
    if (!*head) { *head=node; return; }
    Student *p=*head; while(p->next) p=p->next; p->next=node;
}
Student *find_student(Student *head, int id) {
    for(Student *p=head;p;p=p->next) if(p->id==id) return p;
    return NULL;
}
int remove_student(Student **head, int id) {
    Student *p=*head,*prev=NULL;
    while(p && p->id!=id) { prev=p; p=p->next; }
    if(!p) return 0;
    if(prev) prev->next=p->next; else *head=p->next;
    free(p); return 1;
}
int update_student(Student *head,int id,const char *room,int fee_paid) {
    Student *s=find_student(head,id); if(!s) return 0;
    snprintf(s->room,ROOM_LEN,"%s",room); s->fee_paid=fee_paid; return 1;
}
int count_students(const Student *head) { int n=0; for(;head;head=head->next)n++; return n; }
int save_students(const Student *head,const char *path) {
    FILE *f=fopen(path,"w"); if(!f)return 0;
    for(;head;head=head->next)
        fprintf(f,"%d|%s|%s|%s|%d\n",head->id,head->name,head->room,head->phone,head->fee_paid);
    fclose(f); return 1;
}
int load_students(Student **head,const char *path) {
    FILE *f=fopen(path,"r"); if(!f)return 0;
    char line[256],name[NAME_LEN],room[ROOM_LEN],phone[PHONE_LEN]; int id,paid;
    while(fgets(line,sizeof line,f)) {
        if(sscanf(line,"%d|%79[^|]|%19[^|]|%19[^|]|%d",&id,name,room,phone,&paid)==5)
            if(!find_student(*head,id)) add_student(head,create_student(id,name,room,phone,paid));
    }
    fclose(f); return 1;
}
void display_students(const Student *p) {
    printf("\n%-6s %-24s %-12s %-16s %s\n","ID","STUDENT","ROOM","PHONE","FEE");
    puts("--------------------------------------------------------------------------");
    if(!p) puts("No student records found.");
    for(;p;p=p->next) printf("%-6d %-24s %-12s %-16s %s\n",p->id,p->name,p->room,p->phone,p->fee_paid?"Paid":"Pending");
}
void free_students(Student **head) {
    while(*head) { Student *next=(*head)->next; free(*head); *head=next; }
}
